import os
import json
import hashlib
import urllib.request
import urllib.parse
from datetime import datetime, timezone

import boto3

s3 = boto3.client('s3')
ddb = boto3.resource('dynamodb')
secrets = boto3.client('secretsmanager')

table = ddb.Table(os.environ['DDB_TABLE'])
vt_secret_id = os.environ['VT_SECRET_ID']
VT_BASE = 'https://www.virustotal.com/api/v3/files/'

_vt_key_cache = None

def _get_vt_key():
    """Return VT API key from Secrets Manager, or None if not available."""
    global _vt_key_cache
    if _vt_key_cache:
        return _vt_key_cache
    try:
        resp = secrets.get_secret_value(SecretId=vt_secret_id)
        secret_str = resp.get('SecretString') or '{}'
        _vt_key_cache = json.loads(secret_str).get('VT_API_KEY')
        return _vt_key_cache
    except Exception:
        # No secret value/version yet — treat as missing; scanning will be 'unknown'
        return None

def _sha256_stream(bucket, key): 
    hasher = hashlib.sha256()
    obj = s3.get_object(Bucket=bucket, Key=key)
    body = obj['Body']
    size = obj.get('ContentLength') or 0
    # Stream in chunks; fall back to read() if iter_chunks is not available
    try:
        iterator = getattr(body, 'iter_chunks', None)
        if callable(iterator):
            for chunk in iterator(chunk_size=8 * 1024 * 1024):
                if chunk:
                    hasher.update(chunk)
        else:
            while True:
                chunk = body.read(8 * 1024 * 1024)
                if not chunk:
                    break
                hasher.update(chunk)
    finally:
        try:
            body.close()
        except Exception:
            pass
    return hasher.hexdigest(), size

def _vt_lookup(hash_hex, vt_key):
    """Look up hash in VirusTotal. If no key or network error, return 'unknown'."""
    if not vt_key:
        return {'malicious': 0, 'suspicious': 0, 'undetected': 0, 'result': 'unknown'}
    req = urllib.request.Request(
        VT_BASE + hash_hex,
        headers={'x-apikey': vt_key}
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
            stats = data['data']['attributes']['last_analysis_stats']
            result = 'malicious' if stats.get('malicious', 0) > 0 else (
                'suspicious' if stats.get('suspicious', 0) > 0 else 'clean'
            )
            return {
                'malicious': stats.get('malicious', 0),
                'suspicious': stats.get('suspicious', 0),
                'undetected': stats.get('undetected', 0),
                'result': result,
            }
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return {'malicious': 0, 'suspicious': 0, 'undetected': 0, 'result': 'unknown'}
        return {'malicious': 0, 'suspicious': 0, 'undetected': 0, 'result': 'unknown'}
    except Exception:
        return {'malicious': 0, 'suspicious': 0, 'undetected': 0, 'result': 'unknown'}

def handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])
        uploaded_at = record.get('eventTime', datetime.now(timezone.utc).isoformat()) + 'Z'
        now = datetime.now(timezone.utc).isoformat() + 'Z'
        try:
            sha256, size = _sha256_stream(bucket, key)
            vt_key = _get_vt_key()
            vt = _vt_lookup(sha256, vt_key)
            
            status = vt['result']
            if status in ('malicious', 'suspicious'):
                #delete object from s3 bucket
                s3.delete_object(Bucket=bucket, Key=key)
                status = 'deleted_malicious'
                
            table.put_item(Item={
                'id': key,  # Use S3 object key as the partition key
                'object_key': key,
                'bucket': bucket,
                'size': size,
                'sha256': sha256,
                'status': status,
                'vt_malicious': vt.get('malicious', 0),
                'vt_suspicious': vt.get('suspicious', 0),
                'vt_undetected': vt.get('undetected', 0),
                'uploaded_at': uploaded_at,
                'scanned_at': now,
                'uploader': record.get('userIdentity', {}).get('principalId', 'unknown')
            })
        except Exception as e:
            table.put_item(Item={
                'id': key,
                'object_key': key,
                'bucket': bucket,
                'size': record['s3']['object'].get('size', 0),
                'sha256': 'n/a',
                'status': 'error',
                'error': str(e),
                'uploaded_at': uploaded_at,
            })
            raise
            
        

        
           
           
    